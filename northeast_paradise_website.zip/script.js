
document.getElementById("booking-form").addEventListener("submit", function (e) {
    e.preventDefault();
    alert("Your booking request has been submitted!");
});
